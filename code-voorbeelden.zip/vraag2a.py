# Python programma om te controleren of
# een string een palindrome is of niet


woord = input("geef een woord: ")

# Draai het woord om
woord_achterste_voren = ""
for letter in woord:
   woord_achterste_voren = letter + woord_achterste_voren

if (woord_achterste_voren == woord):
   print(woord, "is een palindrome.")
else:
   print(woord, "is geen palindrome.")
