num1 = float(input("Enter number 1:"))
num2 = float(input("Enter number 2:"))
 
def to_add():
    tot = num1 + num2
    print(f"{num1} + {num2} = {tot}")
 
def to_sub():
    sub = num1 - num2
    print(f"{num1} - {num2} = {sub}")
 
def to_mul():
    mul = num1 * num2
    print(f"{num1} x {num2} = {mul}")
 
def to_div():
    div = num1 / num2
    print(f"{num1} / {num2} = {div}")
 
operation = input("Choose an operation(+,-,*, /):")
if operation == "+":
    to_add()
elif operation == "-":
    to_sub()
elif operation == "*":
    to_mul()
elif operation == "/":
    to_div()
else:
    print(f"No operation for {operation} for now! sorry!")