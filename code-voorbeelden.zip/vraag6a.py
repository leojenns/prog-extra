woord = input("Voer een woord/zin in om te draaien: ")

for index in range(len(woord) - 1, -1, -1):
  print(woord[index], end="")
print("\n")