kleur = input("Welke kleur heeft het verkeerslicht?: ").title()
if kleur == "Rood":
    print("Stop de auto")
elif kleur == "Geel":
    print("Stop de auto")
elif kleur == "Groen":
    print("Je mag doorrijden")
else:
    print("Deze kleur herken ik niet")